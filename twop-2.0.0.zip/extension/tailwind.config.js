/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./webviews/**/*.svelte"],
  theme: {
    extend: {},
  },
  plugins: [],
};

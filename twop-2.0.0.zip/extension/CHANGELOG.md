## [1.0.0]

Initial release

## [2.0.0]

- Bottom counter now resets everyday
- New counter system
    - fix huge counter increases if computer put in sleep mode between two ticks
    - Stored in a in-memory persistent local database
- Clicking on it opens the overview webview with
    - Project stats
    - Time spent working on that project
    - List of the other projects